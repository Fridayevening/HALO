<template>
  <div class="min-h-screen" style="width: 100%; background: linear-gradient(to right, #060606, #6C6969);">
    <!-- ... existing header code ... -->

    <!-- 主要内容区域 -->
    <main class="relative"> <!-- 添加 relative 定位 -->
      <!-- ... other sections ... -->
      <ServiceSection class="relative z-10" /> <!-- 确保 ServiceSection 有正确的层级 -->
      <!-- ... other sections ... -->
    </main>
  </div>
</template> 