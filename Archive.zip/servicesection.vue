<div class="container mx-auto px-4">
  <h2 class="text-4xl font-bold text-center mb-12">OUR SERVICES</h2>
  
  <!-- Services container - vertical layout -->
  <div class="flex flex-col gap-6 max-w-md mx-auto">
    <!-- Industry Research -->
    <div class="bg-gradient-to-b from-[#5A5C4E] to-[#42413D] border border-[#E7F5B1] p-6 rounded-lg">
      <h3 class="text-xl font-bold mb-3">Industry Research and Consulting</h3>
      <p class="text-gray-300">Our experienced team provides tailored industry and competitive research based on your specific niche.</p>
    </div>

    <!-- Global Growth Strategy -->
    <div class="bg-gradient-to-b from-[#5A5C4E] to-[#42413D] border border-[#E7F5B1] p-6 rounded-lg">
      <h3 class="text-xl font-bold mb-3">Customized Global Growth Strategy</h3>
      <ul class="space-y-2 text-gray-300">
        <li>Comprehensive analysis of global market and campaign planning</li>
        <li>Community growth strategies and eco-partnerships development</li>
        <li>Media strategies and top global KOLs collaborations</li>
        <li>Organization of online and offline events</li>
      </ul>
    </div>

    <!-- KOL Collaboration -->
    <div class="bg-gradient-to-b from-[#5A5C4E] to-[#42413D] border border-[#E7F5B1] p-6 rounded-lg">
      <h3 class="text-xl font-bold mb-3">KOL Collaboration and Promotion</h3>
      <p class="text-gray-300 mb-3">We recommend high-quality KOLs that match your project's stage and needs, offering customized support:</p>
      <ul class="space-y-2 text-gray-300">
        <li>Access to over 1300 premium KOLs across key crypto markets</li>
        <li>Connections to 350 diverse crypto communities</li>
      </ul>
    </div>

    <!-- Listing Services -->
    <div class="bg-gradient-to-b from-[#5A5C4E] to-[#42413D] border border-[#E7F5B1] p-6 rounded-lg">
      <h3 class="text-xl font-bold mb-3">Listing Services</h3>
      <ul class="space-y-2 text-gray-300">
        <li>Tailored TGE/listing strategies</li>
        <li>Access to top 10+ exchanges</li>
        <li>Strategic consulting for listings</li>
      </ul>
    </div>

    <!-- Media Partnerships -->
    <div class="bg-gradient-to-b from-[#5A5C4E] to-[#42413D] border border-[#E7F5B1] p-6 rounded-lg">
      <h3 class="text-xl font-bold mb-3">Media Partnerships and Local Brand Exposure</h3>
      <p class="text-gray-300 mb-3">We leverage a wide array of global media resources to help build your brand:</p>
      <ul class="space-y-2 text-gray-300">
        <li>Access to 120+ leading crypto and mainstream media outlets</li>
        <li>Experienced regional partners providing localized exposure opportunities</li>
      </ul>
    </div>
  </div>
</div> 