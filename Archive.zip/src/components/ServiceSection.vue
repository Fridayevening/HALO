<template>
  <section class="py-20 relative">
    <div class="container mx-auto px-4">
      <h2 class="text-4xl font-bold text-center text-white mb-16">OUR SERVICES</h2>
      
      <!-- Services Grid Container -->
      <div class="max-w-7xl mx-auto">
        <!-- Top Service - Full Width -->
        <div class="bg-gradient-to-b from-[#5A5C4E] to-[#42413D] border border-[#E7F5B1] p-6 rounded-lg mb-6">
          <h3 class="text-xl font-bold text-white">Industry Research and Consulting</h3>
          <p class="text-gray-200">Our experienced team provides tailored industry and competitive research based on your specific niche.</p>
        </div>

        <!-- Two Column Layout -->
        <div class="flex flex-col md:flex-row gap-6">
          <!-- Left Column -->
          <div class="md:w-1/2 space-y-6">
            <!-- Global Growth Strategy -->
            <div class="bg-gradient-to-b from-[#5A5C4E] to-[#42413D] border border-[#E7F5B1] p-6 rounded-lg">
              <h3 class="text-xl font-bold text-white mb-4">Global Growth Strategy Development</h3>
              <ul class="list-disc pl-5 space-y-2 text-gray-200">
                <li>Comprehensive analysis of global market and campaign planning</li>
                <li>Community growth strategies and eco-partnerships development</li>
                <li>Media strategies and top global KOLs collaborations</li>
                <li>Organization of online and offline events</li>
              </ul>
            </div>

            <!-- Listing Service -->
            <div class="bg-gradient-to-b from-[#5A5C4E] to-[#42413D] border border-[#E7F5B1] p-6 rounded-lg">
              <h3 class="text-xl font-bold text-white mb-4">Listing Services</h3>
              <ul class="list-disc pl-5 space-y-2 text-gray-200">
                <li>Tailored TGE/listing strategies</li>
                <li>Access to top 10+ exchanges</li>
                <li>Strategic consulting for listings</li>
              </ul>
            </div>
          </div>

          <!-- Right Column -->
          <div class="md:w-1/2 space-y-6">
            <!-- KOL Collaboration -->
            <div class="bg-gradient-to-b from-[#5A5C4E] to-[#42413D] border border-[#E7F5B1] p-6 rounded-lg">
              <h3 class="text-xl font-bold text-white mb-4">KOL Collaboration and Promotion</h3>
              <p class="text-gray-200 mb-3">We recommend high-quality KOLs that match your project's stage and needs, offering customized support:</p>
              <ul class="list-disc pl-5 space-y-2 text-gray-200">
                <li>Access to over 1300 premium KOLs across key crypto markets</li>
                <li>Connections to 350 diverse crypto communities</li>
              </ul>
            </div>

            <!-- Media Partnerships -->
            <div class="bg-gradient-to-b from-[#5A5C4E] to-[#42413D] border border-[#E7F5B1] p-6 rounded-lg">
              <h3 class="text-xl font-bold text-white mb-4">Media Partnerships and Local Brand Exposure</h3>
              <p class="text-gray-200 mb-3">We leverage a wide array of global media resources to help build your brand:</p>
              <ul class="list-disc pl-5 space-y-2 text-gray-200">
                <li>Access to 120+ leading crypto and mainstream media outlets</li>
                <li>Experienced regional partners providing localized exposure opportunities</li>
              </ul>
            </div>
          </div>
        </div>
      </div>
    </div>
  </section>
</template> 