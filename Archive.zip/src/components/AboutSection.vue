<template>
  <section class="py-16">
    <div class="container mx-auto px-6">
      <h2 class="text-4xl font-bold mb-8 text-white text-center">ABOUT HALO TOMORROW</h2>
      <div class=" text-xl max-w-6xl mx-auto text-gray-200 text-left">
        <p class="mb-6">
          We are dedicated to crafting tailored global growth strategies that connect you with premium industry resources. Drawing on extensive experience from leading exchanges and projects worldwide, we provide comprehensive services designed to help you achieve critical business milestones.
        </p>
        <p class="mb-6">
          Our team combines profound industry knowledge with sharp insights and targeted growth strategies. We offer a complete suite of market growth services tailored to the distinct phases of your project’s development, leveraging a vast network of global online and offline resources, including KOLs, medias, exchanges, and venture capitals.
        </p>
        <p class="mb-6">
          Our mission is to deliver exceptional service and real growth, establishing us as your ideal partner for strategic advancement in the Web3 ecosystem.
        </p>
      </div>
    </div>
  </section>
</template>