<template>
  <section class="mt-40 py-16">
    <div class="container mx-auto px-6">
      <div class="max-w-7xl mx-auto">
        <h2 class="text-4xl font-bold mb-12 text-white text-center">WHY CHOSE US</h2>
        
        <div class="flex" style="flex-direction: column">
          <div class="bg-gradient-to-b from-[#5A5C4E] to-[#42413D] border border-[#E7F5B1] p-6 rounded-lg mb-8">
            <h3 class="text-xl font-bold mb-4 text-white">
              Experienced Growth Team
            </h3>
            <p class="text-gray-200 leading-relaxed">
            Our core team comes from leading exchanges and projects in the web3, bringing extensive practical experience in driving growth. We understand the diverse strategies required for different global markets. With strong research capabilities and real-time market insight, we’re equipped to create tailored, high-quality growth strategies that meet your unique needs.
            </p>
          </div>
          
          <div class="bg-gradient-to-b from-[#5A5C4E] to-[#42413D] border border-[#E7F5B1] p-6 rounded-lg mb-8">
            <h3 class="text-xl font-bold mb-4 text-white">
              Extensive Industry Resources
            </h3>
            <ul class="list-disc pl-5 text-gray-200 leading-relaxed">
              <li>We possess a deep understanding of market strategies across various regions, supported by a comprehensive network of online and offline resources in 34 countries.</li>
              <li>Our collaboration with over 1,300 KOLs worldwide, built over five years, ensures a robust foundation of trust and influence.</li>
              <li>Additionally, we provide access to critical resources from top 10+ exchanges, enabling a full suite of growth services tailored to TGE and listing processes, including market partnerships, ecosystem integrations, and listing strategies. We can create customized solutions based on the unique requirements of different exchanges.</li>
              <li>Furthermore, we maintain connections with over 120 prominent crypto and mainstream media outlets, alongside resources from leading industry projects to facilitate cross-brand collaborations.</li>
            </ul>
          </div>

          <div class="bg-gradient-to-b from-[#5A5C4E] to-[#42413D] border border-[#E7F5B1] p-6 rounded-lg mb-8">
            <h3 class="text-xl font-bold mb-4 text-white">
              Comprehensive Communication
            </h3>
            <p class="text-gray-200 leading-relaxed">
            We take a holistic approach to diagnose your project's needs across multiple dimensions, including industry research, consulting, narrative development, infrastructure setup, market growth planning, community management, and TGE. Our aim is to provide all-around, high-quality support that drives real growth for your business.
            </p>
          </div>
        </div>
      </div>
    </div>
  </section>
</template>