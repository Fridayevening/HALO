<template>
  <div class="relative w-full max-w-7xl mx-auto py-20">
    <!-- 标题文字 -->
    <h1 class="text-5xl font-bold text-white text-center mb-20 max-w-4xl mx-auto leading-tight">
      We cover all the key points to take your business from zero to hero.
    </h1>

    <!-- 地球图和数据展示 -->
    <div class="relative w-full h-[500px] flex justify-center items-center">
      <!-- 地球背景图 -->
      <img src="../assets/globe.png" class="absolute w-full h-full object-contain" />
      
      <!-- 数据统计部分 -->
      <div class="absolute bottom-0 w-full flex justify-between px-20">
        <!-- Influencers -->
        <div class="text-center">
          <div class="bg-[#1a1a1a] p-3 rounded-lg mb-2">
            <img src="../assets/icon0.png" alt="Influencers" class="w-6 h-6" />
          </div>
          <div class="text-white font-bold text-2xl">1800+</div>
          <div class="text-gray-400 text-sm">INFLUENCERS</div>
        </div>

        <!-- Audiences -->
        <div class="text-center">
          <div class="bg-[#1a1a1a] p-3 rounded-lg mb-2">
            <img src="../assets/icon1.png" alt="Audiences" class="w-6 h-6" />
          </div>
          <div class="text-white font-bold text-2xl">20M+</div>
          <div class="text-gray-400 text-sm">AUDIENCES</div>
        </div>

        <!-- Trading Volume -->
        <div class="text-center">
          <div class="bg-[#1a1a1a] p-3 rounded-lg mb-2">
            <img src="../assets/icon2.png" alt="Trading Volume" class="w-6 h-6" />
          </div>
          <div class="text-white font-bold text-2xl">180B+</div>
          <div class="text-gray-400 text-sm">TRADING VOLUME GENERATED</div>
        </div>

        <!-- Media House -->
        <div class="text-center">
          <div class="bg-[#1a1a1a] p-3 rounded-lg mb-2">
            <img src="../assets/icon3.png" alt="Media House" class="w-6 h-6" />
          </div>
          <div class="text-white font-bold text-2xl">140+</div>
          <div class="text-gray-400 text-sm">MEDIA HOUSE GLOBALLY</div>
        </div>

        <!-- Countries -->
        <div class="text-center">
          <div class="bg-[#1a1a1a] p-3 rounded-lg mb-2">
            <img src="../assets/icon4.png" alt="Countries" class="w-6 h-6" />
          </div>
          <div class="text-white font-bold text-2xl">34</div>
          <div class="text-gray-400 text-sm">COUNTRIES</div>
        </div>

        <!-- VCs -->
        <div class="text-center">
          <div class="bg-[#1a1a1a] p-3 rounded-lg mb-2">
            <img src="../assets/icon5.png" alt="VCs" class="w-6 h-6" />
          </div>
          <div class="text-white font-bold text-2xl">5+</div>
          <div class="text-gray-400 text-sm">VCs</div>
        </div>
      </div>
    </div>
  </div>
</template> 